export type TokenData = {
    email: string;
    refreshToken: string;
  };
  